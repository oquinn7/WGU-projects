import { Component, OnInit, Inject, Renderer2 } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  constructor(
    private httpClient: HttpClient,
    private renderer: Renderer2,
    @Inject(DOCUMENT) private document: Document
  ) {}

  // Backend API base
  private baseURL: string = 'http://localhost:8080';
  private getUrl: string = this.baseURL + '/room/reservation/v1/';
  private postUrl: string = this.baseURL + '/room/reservation/v1';

  public submitted!: boolean;
  roomsearch!: FormGroup;
  rooms!: Room[];
  request!: ReserveRoomRequest;
  currentCheckInVal!: string;
  currentCheckOutVal!: string;

  // B1 — welcome messages
  welcomeEN!: string;
  welcomeFR!: string;

  // B2 — Currency (values returned from backend)
  usdPrice!: string;
  cadPrice!: string;
  eurPrice!: string;


  // B3 — Time zones
  etTime!: string;
  mtTime!: string;
  utcTime!: string;

  ngOnInit() {

    // FORM SETUP
    this.roomsearch = new FormGroup({
      checkin: new FormControl(''),
      checkout: new FormControl('')
    });

    this.roomsearch.valueChanges.subscribe(x => {
      this.currentCheckInVal = x.checkin;
      this.currentCheckOutVal = x.checkout;
    });

    // =======================================
    // B1 — GET WELCOME MESSAGES FROM BACKEND
    // =======================================
    this.httpClient.get<any>(`${this.baseURL}/api/welcome`)
      .subscribe(data => {
        this.welcomeEN = data.en;
        this.welcomeFR = data.fr;
      });

    // =======================================
    // B2 — GET CONVERTED PRICES
    // =======================================
    this.httpClient.get<any>(`${this.baseURL}/api/prices`)
      .subscribe({
        next: (data) => {
          console.log("PRICE API SUCCESS:", data);
          this.usdPrice = data.usd;
          this.cadPrice = data.cad;
          this.eurPrice = data.eur;
        },
        error: (err) => {
          console.error("PRICE API ERROR:", err);
        }
      });


    // =======================================
    // B3 — GET TIME ZONE CONVERSIONS
    // =======================================
    this.httpClient.get<any>(`${this.baseURL}/api/presentation-times?et=14:00`)
      .subscribe(data => {
        this.etTime = data.et;
        this.mtTime = data.mt;
        this.utcTime = data.utc;
      });
  }

  // ===============================
  //     RESERVATION METHODS
  // ===============================

  onSubmit({ value, valid }: { value: Roomsearch, valid: boolean }) {
    this.getAll().subscribe((rooms) => {
      this.rooms = <Room[]>Object.values(rooms)[0];
    });
  }

  reserveRoom(value: string) {
    this.request = new ReserveRoomRequest(
      value,
      this.currentCheckInVal,
      this.currentCheckOutVal
    );
    this.createReservation(this.request);
  }

  createReservation(body: ReserveRoomRequest) {
    const options = { headers: new HttpHeaders().append('key', 'value') };
    this.httpClient.post(this.postUrl, body, options)
      .subscribe(res => console.log(res));
  }

  getAll(): Observable<any> {
    return this.httpClient.get(
      `${this.baseURL}/room/reservation/v1?checkin=${this.currentCheckInVal}&checkout=${this.currentCheckOutVal}`,
      { responseType: 'json' }
    );
  }
}

// =================== INTERFACES =======================

export interface Roomsearch {
  checkin: string;
  checkout: string;
}

export interface Room {
  id: string;
  roomNumber: string;
  price: string;
  links: string;
}

export class ReserveRoomRequest {
  constructor(
    public roomId: string,
    public checkin: string,
    public checkout: string
  ) {}
}
