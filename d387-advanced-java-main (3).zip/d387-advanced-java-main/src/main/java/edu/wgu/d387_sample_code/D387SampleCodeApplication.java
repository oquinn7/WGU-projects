package edu.wgu.d387_sample_code;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Locale;
import java.util.ResourceBundle;
import java.time.*;
import java.time.format.DateTimeFormatter;

@SpringBootApplication
public class D387SampleCodeApplication {

    public static void main(String[] args) {
        SpringApplication.run(D387SampleCodeApplication.class, args);

        // ==========================
        // B1a & B1b: Multithreading
        // ==========================

        Runnable englishTask = () -> {
            ResourceBundle bundle = ResourceBundle.getBundle("welcome_en");
            System.out.println("English Thread: " + bundle.getString("welcome"));
        };

        Runnable frenchTask = () -> {
            ResourceBundle bundle = ResourceBundle.getBundle("welcome_fr");
            System.out.println("French Thread: " + bundle.getString("welcome"));
        };

        Thread englishThread = new Thread(englishTask);
        Thread frenchThread = new Thread(frenchTask);

        englishThread.start();
        frenchThread.start();

        try {
            englishThread.join();
            frenchThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // ==========================
        // B3a & B3b: Time Conversion
        // ==========================
        System.out.println("\n--- Time Zone Conversion ---");

        LocalTime presentationTime = LocalTime.of(14, 30);

        ZonedDateTime eastern = ZonedDateTime.of(
                LocalDate.now(),
                presentationTime,
                ZoneId.of("America/New_York")
        );

        ZonedDateTime mountain = eastern.withZoneSameInstant(ZoneId.of("America/Denver"));
        ZonedDateTime utc = eastern.withZoneSameInstant(ZoneId.of("UTC"));

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("hh:mm a z");

        System.out.println("ET:  " + fmt.format(eastern));
        System.out.println("MT:  " + fmt.format(mountain));
        System.out.println("UTC: " + fmt.format(utc));
    }
}
