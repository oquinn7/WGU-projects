package edu.wgu.d387_sample_code.rest;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@CrossOrigin
@RequestMapping("/api")
public class WelcomeController {

    @GetMapping("/welcome")
    public Map<String, String> getWelcomeMessages() {

        // Load your existing bundles
        ResourceBundle enBundle =
                ResourceBundle.getBundle("welcome", Locale.ENGLISH);

        ResourceBundle frBundle =
                ResourceBundle.getBundle("welcome", Locale.FRENCH);

        Map<String, String> result = new HashMap<>();
        result.put("en", enBundle.getString("welcome"));
        result.put("fr", frBundle.getString("welcome"));

        return result;
    }
}
