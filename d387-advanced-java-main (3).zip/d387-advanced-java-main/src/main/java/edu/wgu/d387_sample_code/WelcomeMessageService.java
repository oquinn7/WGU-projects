package edu.wgu.d387_sample_code;

import java.util.Locale;
import java.util.ResourceBundle;

public class WelcomeMessageService {

    public void displayWelcomeMessages() {

        Thread englishThread = new Thread(() -> {
            ResourceBundle bundle = ResourceBundle.getBundle("messages", Locale.ENGLISH);
            System.out.println("English: " + bundle.getString("welcome"));
        });

        Thread frenchThread = new Thread(() -> {
            ResourceBundle bundle = ResourceBundle.getBundle("messages", Locale.CANADA_FRENCH);
            System.out.println("French: " + bundle.getString("welcome"));
        });

        englishThread.start();
        frenchThread.start();

        try {
            englishThread.join();
            frenchThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
