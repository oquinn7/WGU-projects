package edu.wgu.d387_sample_code;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
public class PriceController {

    @GetMapping("/api/prices")
    public Map<String, String> getPrices() {

        double usd = 199.00;
        double cad = usd * 1.36; // convert USD → CAD
        double eur = usd * 0.91; // convert USD → EUR

        Map<String, String> prices = new HashMap<>();
        prices.put("usd", "USD: $" + String.format("%.2f", usd));
        prices.put("cad", "CAD: C$" + String.format("%.2f", cad));
        prices.put("eur", "EUR: €" + String.format("%.2f", eur));

        return prices;
    }
}