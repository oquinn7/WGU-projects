package edu.wgu.d387_sample_code.rest;

import edu.wgu.d387_sample_code.convertor.*;
import edu.wgu.d387_sample_code.entity.ReservationEntity;
import edu.wgu.d387_sample_code.entity.RoomEntity;
import edu.wgu.d387_sample_code.model.request.ReservationRequest;
import edu.wgu.d387_sample_code.model.response.ReservableRoomResponse;
import edu.wgu.d387_sample_code.model.response.ReservationResponse;
import edu.wgu.d387_sample_code.repository.ReservationRepository;
import edu.wgu.d387_sample_code.repository.RoomRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.convert.ConversionService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import org.springframework.format.annotation.DateTimeFormat;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(ResourceConstants.ROOM_RESERVATION_V1)
@CrossOrigin
public class ReservationResource {

    @Autowired
    ApplicationContext context;

    @Autowired
    RoomRepository roomRepository;

    @Autowired
    ReservationRepository reservationRepository;

    @Autowired
    ConversionService conversionService;

    @Autowired
    private RoomEntityToReservableRoomResponseConverter converter;

    // ============================================================
    // GET AVAILABLE ROOMS
    // ============================================================
    @RequestMapping(path ="", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Page<ReservableRoomResponse> getAvailableRooms(
            @RequestParam(value = "checkin")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate checkin,

            @RequestParam(value = "checkout")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate checkout,

            Pageable pageable) {

        RoomService roomService = context.getBean(RoomServiceImpl.class);
        ReservationService reservationService = context.getBean(ReservationServiceImpl.class);

        List<RoomEntity> allRooms = roomService.findAll();
        List<ReservationEntity> allReservations = reservationService.findAll();

        for (ReservationEntity reservationEntity : allReservations) {
            LocalDate rcheckin = reservationEntity.getCheckin();
            LocalDate rcheckout = reservationEntity.getCheckout();

            boolean overlap =
                    (rcheckin.isBefore(checkin) && rcheckout.isAfter(checkin)) ||
                            (rcheckin.isAfter(checkin) && rcheckin.isBefore(checkout)) ||
                            rcheckin.isEqual(checkin);

            if (overlap) {
                allRooms.remove(reservationEntity.getRoomEntity());
            }
        }

        Page<RoomEntity> page = new PageImpl<>(allRooms);
        return page.map(converter::convert);
    }

    // ============================================================
    // GET A ROOM BY ID
    // ============================================================
    @RequestMapping(path = "/{roomId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<RoomEntity> getRoomById(@PathVariable Long roomId) {

        Optional<RoomEntity> result = roomRepository.findById(roomId);

        if (result.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        return new ResponseEntity<>(result.get(), HttpStatus.OK);
    }

    // ============================================================
    // CREATE A RESERVATION
    // ============================================================
    @RequestMapping(path = "", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ReservationResponse> createReservation(
            @RequestBody ReservationRequest reservationRequest) {

        ReservationEntity reservationEntity =
                conversionService.convert(reservationRequest, ReservationEntity.class);

        reservationRepository.save(reservationEntity);

        ReservationService repository = context.getBean(ReservationServiceImpl.class);
        reservationEntity = repository.findLast();

        Optional<RoomEntity> result = roomRepository.findById(reservationRequest.getRoomId());

        if (result.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        RoomEntity roomEntity = result.get();
        roomEntity.addReservationEntity(reservationEntity);

        roomRepository.save(roomEntity);
        reservationEntity.setRoomEntity(roomEntity);

        ReservationResponse reservationResponse =
                conversionService.convert(reservationEntity, ReservationResponse.class);

        return new ResponseEntity<>(reservationResponse, HttpStatus.CREATED);
    }

    // ============================================================
    // UPDATE RESERVATION (NOT IMPLEMENTED)
    // ============================================================
    @RequestMapping(path = "", method = RequestMethod.PUT,
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ReservableRoomResponse> updateReservation(
            @RequestBody ReservationRequest reservationRequest) {

        return new ResponseEntity<>(new ReservableRoomResponse(), HttpStatus.OK);
    }

    // ============================================================
    // DELETE RESERVATION
    // ============================================================
    @RequestMapping(path = "/{reservationId}", method = RequestMethod.DELETE)
    public ResponseEntity<Void> deleteReservation(@PathVariable long reservationId) {

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}