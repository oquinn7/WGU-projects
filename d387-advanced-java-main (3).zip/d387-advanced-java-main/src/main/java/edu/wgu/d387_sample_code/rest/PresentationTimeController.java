package edu.wgu.d387_sample_code.rest;

import org.springframework.web.bind.annotation.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

@RestController
@CrossOrigin
@RequestMapping("/api")
public class PresentationTimeController {

    @GetMapping("/presentation-times")
    public Map<String, String> getTimes(@RequestParam String et) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");

        LocalTime etTime = LocalTime.parse(et, formatter);

        ZonedDateTime etZoned = etTime.atDate(LocalDate.now()).atZone(ZoneId.of("America/New_York"));
        ZonedDateTime mtZoned = etZoned.withZoneSameInstant(ZoneId.of("America/Denver"));
        ZonedDateTime utcZoned = etZoned.withZoneSameInstant(ZoneId.of("UTC"));

        Map<String, String> result = new HashMap<>();
        result.put("et", etZoned.format(formatter));
        result.put("mt", mtZoned.format(formatter));
        result.put("utc", utcZoned.format(formatter));

        return result;
    }
}
