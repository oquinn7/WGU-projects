package edu.wgu.d387_sample_code.service;

import org.springframework.stereotype.Service;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Map;

@Service
public class TimeService {
    private static final ZoneId ET  = ZoneId.of("America/New_York");
    private static final ZoneId MT  = ZoneId.of("America/Denver");
    private static final ZoneId UTC = ZoneId.of("UTC");
    private static final DateTimeFormatter HHMM = DateTimeFormatter.ofPattern("HH:mm");

    /**
     * Input: ET time in HH:mm (e.g., "14:00").
     * Output: map of ET/MT/UTC formatted as "HH:mm <TZ>".
     */
    public Map<String, String> presentationTimes(String hourMinuteEt) {
        LocalTime base = LocalTime.parse(hourMinuteEt, HHMM);
        LocalDate today = LocalDate.now(ET);

        ZonedDateTime et  = ZonedDateTime.of(today, base, ET);
        ZonedDateTime mt  = et.withZoneSameInstant(MT);
        ZonedDateTime utc = et.withZoneSameInstant(UTC);

        return Map.of(
            "et",  et.format(HHMM)  + " ET",
            "mt",  mt.format(HHMM)  + " MT",
            "utc", utc.format(HHMM) + " UTC"
        );
    }
}
