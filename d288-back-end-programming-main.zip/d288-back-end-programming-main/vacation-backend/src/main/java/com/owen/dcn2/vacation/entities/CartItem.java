package com.owen.dcn2.vacation.entities;

import jakarta.persistence.*;
import lombok.Data;
import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "cart_items")
@Data
public class CartItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cart_item_id")
    private Long id;

    @Column(name = "create_date")
    private Date createDate;

    @Column(name = "last_update")
    private Date lastUpdate;

    // Cart this item belongs to
    @ManyToOne
    @JoinColumn(name = "cart_id")
    private Cart cart;

    // Vacation in this cart item
    @ManyToOne
    @JoinColumn(name = "vacation_id")
    private Vacation vacation;

    // Excursions selected with this vacation
    @ManyToMany
    @JoinTable(
            name = "excursion_cartitem",
            joinColumns = @JoinColumn(name = "cart_item_id"),
            inverseJoinColumns = @JoinColumn(name = "excursion_id")
    )
    private Set<Excursion> excursions;
}
