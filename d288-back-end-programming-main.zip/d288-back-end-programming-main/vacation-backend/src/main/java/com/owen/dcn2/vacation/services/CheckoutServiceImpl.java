package com.owen.dcn2.vacation.services;

import com.owen.dcn2.vacation.dao.CartRepository;
import com.owen.dcn2.vacation.entities.*;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.UUID;

@Service
public class CheckoutServiceImpl implements CheckoutService {

    private final CartRepository cartRepository;

    public CheckoutServiceImpl(CartRepository cartRepository) {
        this.cartRepository = cartRepository;
    }

    @Override
    public PurchaseResponse placeOrder(Purchase purchase) {

        // Retrieve the cart, customer, and cart items from the purchase
        Cart cart = purchase.getCart();
        Customer customer = purchase.getCustomer();
        Set<CartItem> cartItems = purchase.getCartItems();

        // Generate a tracking number
        String orderTrackingNumber = generateTrackingNumber();
        cart.setOrderTrackingNumber(orderTrackingNumber);

        // Set associations
        cart.setCustomer(customer);

        for (CartItem item : cartItems) {
            item.setCart(cart);
        }

        cart.setCartItems(cartItems);

        // Save the order (cascades the cart items)
        cartRepository.save(cart);

        // Return response object
        return new PurchaseResponse(orderTrackingNumber);
    }

    private String generateTrackingNumber() {
        return UUID.randomUUID().toString();
    }
}

