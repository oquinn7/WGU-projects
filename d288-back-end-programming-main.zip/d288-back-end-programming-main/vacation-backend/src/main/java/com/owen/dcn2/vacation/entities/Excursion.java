package com.owen.dcn2.vacation.entities;

import jakarta.persistence.*;
import lombok.Data;
import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "excursions")
@Data
public class Excursion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "excursion_id")
    private Long id;

    @Column(name = "excursion_title")
    private String excursionTitle;

    @Column(name = "excursion_price")
    private double excursionPrice;

    @Column(name = "image_url")
    private String imageUrl;

    @Column(name = "create_date")
    private Date createDate;

    @Column(name = "last_update")
    private Date lastUpdate;

    // Each excursion belongs to ONE vacation
    @ManyToOne
    @JoinColumn(name = "vacation_id")
    private Vacation vacation;

    // Many-to-many with CartItem handled through a join table
    @ManyToMany(mappedBy = "excursions")
    private Set<CartItem> cartItems;
}
