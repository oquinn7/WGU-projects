
package com.owen.dcn2.vacation.entities;

import lombok.Data;

@Data
public class PurchaseResponse {

    private final String orderTrackingNumber;

}
