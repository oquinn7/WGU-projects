package com.owen.dcn2.vacation.services;

import com.owen.dcn2.vacation.entities.Purchase;
import com.owen.dcn2.vacation.entities.PurchaseResponse;

public interface CheckoutService {

    PurchaseResponse placeOrder(Purchase purchase);

}

