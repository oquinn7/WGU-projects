package com.owen.dcn2.vacation.entities;

public enum StatusType {
    pending,
    ordered,
    canceled
}

