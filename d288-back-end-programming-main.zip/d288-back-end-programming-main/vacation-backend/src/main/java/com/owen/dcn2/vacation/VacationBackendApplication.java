package com.owen.dcn2.vacation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VacationBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(VacationBackendApplication.class, args);
    }

}
