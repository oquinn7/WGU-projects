import pandas as pd
import joblib
from pathlib import Path
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

DATA_PATH = Path("data/preprocessed_telco.csv")
MODEL_DIR = Path("models")
MODEL_DIR.mkdir(exist_ok=True)

def eval_report(name, y_true, y_pred):
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred)
    rec = recall_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred)
    print(f"{name}: Acc={acc:.3f} Prec={prec:.3f} Rec={rec:.3f} F1={f1:.3f}")

if __name__ == "__main__":
    df = pd.read_csv(DATA_PATH)
    y = df["Churn"]
    X = df.drop(columns=["Churn"])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    cat_cols = X.select_dtypes(include="object").columns.tolist()
    num_cols = X.select_dtypes(include=["int64", "float64"]).columns.tolist()

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), num_cols),
            ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
        ]
    )

    # Logistic Regression
    lr = Pipeline([("prep", preprocessor), ("clf", LogisticRegression(max_iter=1000))])
    lr.fit(X_train, y_train)
    eval_report("LogReg", y_test, lr.predict(X_test))
    joblib.dump(lr, MODEL_DIR / "logreg.pkl")

    # Random Forest
    rf = Pipeline([("prep", preprocessor), ("clf", RandomForestClassifier(random_state=42))])
    rf.fit(X_train, y_train)
    eval_report("RandomForest", y_test, rf.predict(X_test))
    joblib.dump(rf, MODEL_DIR / "random_forest.pkl")
