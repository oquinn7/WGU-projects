import pandas as pd
from pathlib import Path

RAW_PATH = Path("data/telco_customer_churn.csv")
CLEAN_PATH = Path("data/preprocessed_telco.csv")

def load_and_clean(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)

    # Drop ID column if present
    if "customerID" in df.columns:
        df = df.drop(columns=["customerID"])

    # Ensure numeric TotalCharges
    if "TotalCharges" in df.columns:
        df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")

    # Target encoding: Yes/No -> 1/0
    if "Churn" not in df.columns:
        raise ValueError("Target column 'Churn' not found")
    df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0}).astype(int)

    # Fill numeric nulls with median
    for c in df.select_dtypes(include="number").columns:
        df[c] = df[c].fillna(df[c].median())

    # Fill categorical nulls with mode
    for c in df.select_dtypes(include="object").columns:
        df[c] = df[c].fillna(df[c].mode()[0])

    return df

def main():
    assert RAW_PATH.exists(), f"Missing file: {RAW_PATH}"
    df = load_and_clean(RAW_PATH)
    df.to_csv(CLEAN_PATH, index=False)
    print(f"Saved {CLEAN_PATH} with shape {df.shape}")

if __name__ == "__main__":
    main()
