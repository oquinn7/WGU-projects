import pandas as pd
import joblib
from pathlib import Path
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

DATA_PATH = Path("data/preprocessed_telco.csv")
BEST_MODEL_PATH = Path("models/best_model.pkl")
METRICS_PATH = Path("models/metrics.txt")

if __name__ == "__main__":
    # Load data
    df = pd.read_csv(DATA_PATH)
    y = df["Churn"]
    X = df.drop(columns=["Churn"])

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Columns by type
    cat_cols = X.select_dtypes(include="object").columns.tolist()
    num_cols = X.select_dtypes(include=["int64", "float64"]).columns.tolist()

    # Preprocessor
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), num_cols),
            ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
        ]
    )

    # Base pipeline
    pipe = Pipeline([("prep", preprocessor),
                     ("clf", RandomForestClassifier(random_state=42))])

    # ---- B5: Cross-validation (5-fold) on full data with F1 ----
    cv_scores = cross_val_score(pipe, X, y, cv=5, scoring="f1")
    print(f"5-fold CV F1 mean: {cv_scores.mean():.3f} (+/- {cv_scores.std():.3f})")

    # ---- B6: Hyperparameter tuning with GridSearchCV ----
    param_grid = {
        "clf__n_estimators": [100, 200, 300],
        "clf__max_depth": [None, 10, 15],
        "clf__min_samples_split": [2, 5, 10],
        "clf__min_samples_leaf": [1, 2, 4],
    }
    grid = GridSearchCV(
        estimator=pipe,
        param_grid=param_grid,
        cv=5,
        scoring="f1",
        n_jobs=-1,
        verbose=0
    )
    grid.fit(X_train, y_train)
    print("Best params:", grid.best_params_)

    # Evaluate best model on held-out test set
    best = grid.best_estimator_
    y_pred = best.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    print(f"Optimized RF - Acc={acc:.3f} Prec={prec:.3f} Rec={rec:.3f} F1={f1:.3f}")

    # Save best model
    BEST_MODEL_PATH.parent.mkdir(exist_ok=True)
    joblib.dump(best, BEST_MODEL_PATH)
    print(f"Saved {BEST_MODEL_PATH}")

    # Also save a metrics txt for your README/screenshots
    METRICS_PATH.write_text(
        "5-fold CV F1 mean: " + f"{cv_scores.mean():.3f} (+/- {cv_scores.std():.3f})\n"
        + "Best params: " + str(grid.best_params_) + "\n"
        + f"Test Acc={acc:.3f} Prec={prec:.3f} Rec={rec:.3f} F1={f1:.3f}\n"
    )
    print(f"Wrote metrics to {METRICS_PATH}")
