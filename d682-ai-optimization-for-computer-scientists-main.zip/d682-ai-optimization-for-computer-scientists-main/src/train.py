"""
DQN1 — Implementing and Testing AI Solutions (C1, D1, D2)

Run examples:
  python -m src.train --data_path "data/DQN1 Dataset.xlsx" --target "AQI"
  python .\src\train.py --data_path "data/DQN1 Dataset.xlsx" --target "AQI"

What this script does:
  - Loads Excel data (sheet optional)
  - Splits features/target
  - Minimal numeric preprocessing
  - Trains XGBoost regressor
  - Computes RMSE and R2 (D1/D2)
  - Saves results to results/ (metrics.json, feature_importance.csv)
"""

import argparse
import json
import pathlib
from typing import Dict, Optional

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from xgboost import XGBRegressor

# Support running either as a package (-m src.train) or as a script (src/train.py)
try:
    from .utils import load_excel, split_features_target, to_numeric_minimal
except Exception:
    from utils import load_excel, split_features_target, to_numeric_minimal


def evaluate_regression(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    """Return two metrics required by D1/D2: RMSE and R2."""
    mse = mean_squared_error(y_true, y_pred)
    rmse = mse ** 0.5  # manual square root
    r2 = r2_score(y_true, y_pred)
    return {"rmse": float(rmse), "r2": float(r2)}

def main(
    data_path: str,
    target: str,
    test_size: float = 0.2,
    sheet: Optional[str] = None,
):
    # --- Load ---
    df = load_excel(data_path, sheet=sheet)
    print(f"[INFO] Loaded data: shape={df.shape}")
    print(f"[INFO] Columns: {list(df.columns)}")

    # --- Split ---
    X_raw, y_raw = split_features_target(df, target)

    # y must be numeric for regression
    y = pd.to_numeric(y_raw, errors="coerce").fillna(y_raw.median(numeric_only=True))

    # --- Minimal preprocessing (robust for tabular data) ---
    X = to_numeric_minimal(X_raw)

    # In case target still has NaNs after coercion:
    not_nan = y.notna()
    X = X.loc[not_nan]
    y = y.loc[not_nan]

    # --- Split into train/test ---
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42
    )

    # --- Model: Gradient-Boosted Trees (XGBoost) ---
    model = XGBRegressor(
        n_estimators=400,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.9,
        colsample_bytree=0.9,
        random_state=42,
        n_jobs=4,
        tree_method="hist",  # fast & CI-friendly on Windows
    )

    # Train
    model.fit(X_train, y_train)

    # Predict & evaluate
    y_pred = model.predict(X_test)
    metrics = evaluate_regression(y_test.values, y_pred)
    print(f"[METRICS] RMSE={metrics['rmse']:.4f} | R2={metrics['r2']:.4f}")

    # --- Save artifacts required for D2 ---
    repo_root = pathlib.Path(__file__).resolve().parents[1]
    results_dir = repo_root / "results"
    results_dir.mkdir(parents=True, exist_ok=True)

    with open(results_dir / "metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

    fi = pd.Series(model.feature_importances_, index=X.columns).sort_values(ascending=False)
    fi.to_csv(results_dir / "feature_importance.csv", index=True)
    print(f"[INFO] Saved: {results_dir / 'metrics.json'}")
    print(f"[INFO] Saved: {results_dir / 'feature_importance.csv'}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_path", type=str, required=True, help="Path to Excel dataset")
    parser.add_argument("--target", type=str, required=True, help="Target column name (e.g., 'AQI')")
    parser.add_argument("--test_size", type=float, default=0.2)
    parser.add_argument("--sheet", type=str, default=None, help="Optional Excel sheet name")
    args = parser.parse_args()

    main(
        data_path=args.data_path,
        target=args.target,
        test_size=args.test_size,
        sheet=args.sheet,
    )
