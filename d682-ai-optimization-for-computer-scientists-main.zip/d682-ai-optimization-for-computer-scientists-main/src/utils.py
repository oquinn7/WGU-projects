import pandas as pd
from typing import Tuple, Optional


def load_excel(path: str, sheet: Optional[str] = None) -> pd.DataFrame:
    """
    Load an Excel file into a pandas DataFrame.

    Args:
        path: Path to the .xlsx file.
        sheet: Optional sheet name. If None, uses the first sheet.

    Returns:
        Cleaned DataFrame with empty rows/cols removed.
    """
    # pandas will use openpyxl under the hood (already installed)
    df = pd.read_excel(path, sheet_name=sheet)
    # Drop completely empty rows/columns to avoid weird shapes
    df = df.dropna(axis=0, how="all").dropna(axis=1, how="all")
    return df


def split_features_target(df: pd.DataFrame, target_col: str) -> Tuple[pd.DataFrame, pd.Series]:
    """
    Split a DataFrame into features (X) and target (y).

    Raises:
        ValueError if the target column is missing.
    """
    if target_col not in df.columns:
        raise ValueError(
            f"Target column '{target_col}' not found. "
            f"Available columns: {list(df.columns)}"
        )
    X = df.drop(columns=[target_col])
    y = df[target_col]
    return X, y


def to_numeric_minimal(X: pd.DataFrame) -> pd.DataFrame:
    """
    Convert columns to numeric when possible; drop the rest.
    This keeps the pipeline simple and robust for CI.

    Note:
      - If you want to keep categoricals, you could replace this with:
            X = pd.get_dummies(X, drop_first=True)
        But for many AQI-style datasets, most features are already numeric.
    """
    numeric_cols = []
    for c in X.columns:
        # Try convert; if it becomes all NaN, we will drop later
        X[c] = pd.to_numeric(X[c], errors="coerce")
        numeric_cols.append(c)
    X = X[numeric_cols]
    # Fill NaNs with medians (column-wise) so models can train
    X = X.fillna(X.median(numeric_only=True))
    return X
