# ALN2 — Task 1 (D287): Web-Based Spring Inventory Application

**Customer:** Furniture Depot  
**Framework:** Spring Boot + Thymeleaf  
**Repo:** https://gitlab.com/wgu-gitlab-environment/student-repos/oquinn7/d287-java-frameworks

This README documents every change for prompts **C–J** with **prompt**, **file**, **line numbers**, and **what changed** (rubric B requirement).  
> Line numbers will be filled in after all code changes are finalized.

---

## C. Customize UI (shop/product/part names)
- **Prompt:** Customize HTML UI to show shop name, product names, part names.  
- **File:** `src/main/resources/templates/mainscreen.html`  
- **Lines:** _TBD_  
- **Change:** Added **Furniture Depot** branding and ensured table headings/rows show product & part names.

## D. About page + navigation
- **Prompt:** Add About page and navigation to/from main screen.  
- **File:** `src/main/java/com/example/demo/web/AboutController.java`  
- **Lines:** _TBD_  
- **Change:** New controller with `/about` endpoint and link back to main screen.

- **File:** `src/main/resources/templates/about.html`  
- **Lines:** _TBD_  
- **Change:** Company description + navigation link to main screen.

## E. Sample inventory (5 parts, 5 products; only when empty; dedupe via multi-pack)
- **Prompt:** Seed inventory only when both Part and Product repositories are empty; use Set for parts; handle duplicates with “(2-pack)” multi-pack naming.  
- **File:** `src/main/java/com/example/demo/bootstrap/BootStrapData.java`  
- **Lines:** _TBD_  
- **Change:** Inserted 5 parts + 5 products appropriate for furniture; guarded by empty-list check.

## F. “Buy Now” button (decrement product inventory; success/failure message)
- **Prompt:** Add “Buy Now” next to Update/Delete; decrement only the product inventory by 1; show success/failure message.  
- **File:** `src/main/resources/templates/mainscreen.html`  
- **Lines:** _TBD_  
- **Change:** Added button and flash message block.

- **File:** `src/main/java/com/example/demo/web/ProductController.java`  
- **Lines:** _TBD_  
- **Change:** Added `@PostMapping("/products/{id}/buy")` to decrement inventory or show out-of-stock message.

## G. Min/Max on Parts (+ forms + persistence filename + enforcement)
- **Prompt:** Add `min` and `max` fields on Part; include in sample inventory; add inputs to Inhouse/Outsourced forms; rename data file; enforce `min <= inv <= max`.  
- **File:** `src/main/java/com/example/demo/domain/Part.java`  
- **Lines:** _TBD_  
- **Change:** Added `min`/`max` fields and helper logic.

- **File:** `src/main/resources/templates/inhousePartForm.html` and `outsourcedPartForm.html`  
- **Lines:** _TBD_  
- **Change:** Added inputs for `min` and `max`.

- **File:** `src/main/java/com/example/demo/service/PartService.java`  
- **Lines:** _TBD_  
- **Change:** Enforced inventory between min and max.

## H. Validation messages (min/max & product-part cascades)
- **Prompt:** Show errors when Part inventory < min or > max, or when Product updates drop any Part below min.  
- **File:** `src/main/java/com/example/demo/web/PartController.java` and `ProductController.java`  
- **Lines:** _TBD_  
- **Change:** Added BindingResult validation and Thymeleaf error messages.

## I. Unit tests for Part min/max
- **Prompt:** Add ≥ 2 tests for min/max bounds.  
- **File:** `src/test/java/com/example/demo/domain/PartTest.java`  
- **Lines:** _TBD_  
- **Change:** Tests for below-min invalid, above-max invalid, within-bounds valid.

## J. Clean code (remove unused validators)
- **Prompt:** Remove class files for unused validators.  
- **File:** `src/main/java/com/example/demo/validators/DeletePartValidator.java`  
- **Lines:** _Removed_  
- **Change:** Deleted unused class.
