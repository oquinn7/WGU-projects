package com.example.demo.domain;

import com.example.demo.validators.ValidDeletePart;

import javax.persistence.*;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@ValidDeletePart
@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "part_type", discriminatorType = DiscriminatorType.INTEGER)
@Table(name = "Parts")
public abstract class Part implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(nullable = false)
    @NotBlank(message = "Name is required")
    private String name;

    @Column(nullable = false)
    @PositiveOrZero(message = "Price value must be positive")
    private double price;

    @Column(nullable = false)
    @Min(value = 0, message = "Inventory value must be positive")
    private int inv;

    /** Minimum inventory allowed (inclusive). */
    @Column(nullable = false)
    @NotNull(message = "Min is required")
    @Min(value = 0, message = "Min must be positive")
    private Integer min;

    /** Maximum inventory allowed (inclusive). */
    @Column(nullable = false)
    @NotNull(message = "Max is required")
    @Min(value = 0, message = "Max must be positive")
    private Integer max;

    @ManyToMany
    @JoinTable(
            name = "product_part",
            joinColumns = @JoinColumn(name = "part_id"),
            inverseJoinColumns = @JoinColumn(name = "product_id")
    )
    private Set<Product> products = new HashSet<>();

    public Part() {}

    public Part(String name, double price, int inv) {
        this.name = name;
        this.price = price;
        this.inv = inv;
    }

    public Part(long id, String name, double price, int inv) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.inv = inv;
    }

    // getters / setters
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getInv() { return inv; }
    public void setInv(int inv) { this.inv = inv; }

    public Integer getMin() { return min; }
    public void setMin(Integer min) { this.min = min; }

    public Integer getMax() { return max; }
    public void setMax(Integer max) { this.max = max; }

    public Set<Product> getProducts() { return products; }
    public void setProducts(Set<Product> products) { this.products = products; }

    @Override public String toString() { return this.name; }

    // ========= Cross-field validation =========

    /** A: Min must be <= Max. */
    @AssertTrue(message = "Min must be less than or equal to Max")
    public boolean isMinLessOrEqualMax() {
        if (min == null || max == null) return true; // @NotNull handles nulls
        return min <= max;
    }

    /** B+C: Inventory must be between Min and Max (inclusive). */
    @AssertTrue(message = "Inventory must be between Min and Max")
    public boolean isInvBetweenMinMax() {
        if (min == null || max == null) return true; // @NotNull handles nulls
        return inv >= min && inv <= max;
    }

    // ---- Alias getters so Thymeleaf/Spring can read these as properties ----
    // (They are not DB columns; mark @Transient.)
    @Transient
    public Boolean getMinLessOrEqualMax() {
        return isMinLessOrEqualMax();
    }

    @Transient
    public Boolean getInvBetweenMinMax() {
        return isInvBetweenMinMax();
    }

    // equals / hashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Part)) return false;
        return id == ((Part) o).id;
    }
    @Override
    public int hashCode() { return Long.hashCode(id); }
}
