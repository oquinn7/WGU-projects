package com.example.demo.controllers;

import com.example.demo.domain.OutsourcedPart;
import com.example.demo.service.OutsourcedPartService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;

@SuppressWarnings("unused")
@Controller
public class AddOutsourcedPartController {

    private final OutsourcedPartService outsourcedPartService;

    public AddOutsourcedPartController(OutsourcedPartService outsourcedPartService) {
        this.outsourcedPartService = outsourcedPartService;
    }

    // ✅ Always ensure a model object exists (prevents Thymeleaf binding errors)
    @ModelAttribute("outsourcedpart")
    public OutsourcedPart ensureOutsourcedPart() {
        return new OutsourcedPart();
    }

    // ✅ Add new outsourced part form
    @GetMapping("/showFormAddOutPart")
    public String showFormAddOutsourcedPart(Model model) {
        if (!model.containsAttribute("outsourcedpart")) {
            model.addAttribute("outsourcedpart", new OutsourcedPart());
        }
        return "OutsourcedPartForm";
    }

    // ✅ Edit (update) existing outsourced part form
    @GetMapping("/editOutPart/{id}")
    public String editOutsourcedPart(@PathVariable int id, Model model) {
        OutsourcedPart existing = outsourcedPartService.findById(id);
        if (existing == null) {
            model.addAttribute("outsourcedpart", new OutsourcedPart());
        } else {
            model.addAttribute("outsourcedpart", existing);
        }
        return "OutsourcedPartForm";
    }

    // ✅ Save part (handles both add & update)
    @PostMapping("/showFormAddOutPart")
    public String submitForm(
            @Valid @ModelAttribute("outsourcedpart") OutsourcedPart part,
            BindingResult binding,
            Model model) {

        model.addAttribute("outsourcedpart", part);

        // If validation fails, stay on the same page
        if (binding.hasErrors()) {
            return "OutsourcedPartForm";
        }

        // Preserve existing product links on edit
        if (part.getId() > 0) {
            OutsourcedPart existing = outsourcedPartService.findById((int) part.getId());
            if (existing != null) {
                part.setProducts(existing.getProducts());
            }
        }

        // Save and show confirmation
        outsourcedPartService.save(part);
        return "confirmationaddpart";
    }
}
