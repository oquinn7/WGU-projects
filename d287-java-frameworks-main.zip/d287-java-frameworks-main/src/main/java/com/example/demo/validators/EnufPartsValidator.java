package com.example.demo.validators;

import com.example.demo.domain.Part;
import com.example.demo.domain.Product;
import com.example.demo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;


public class EnufPartsValidator implements ConstraintValidator<ValidEnufParts, Product> {

    @Autowired
    private ProductService productService;

    public EnufPartsValidator() {
        // no-arg ctor required by Hibernate Validator
    }

    @Override
    public void initialize(ValidEnufParts constraintAnnotation) {
        // Ensure Spring performs dependency injection even if Hibernate created this instance
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }

    @Override
    public boolean isValid(Product product, ConstraintValidatorContext ctx) {
        if (product == null) return true;

        // If Spring didn't inject yet (e.g., during early bootstrap/seed), skip validation
        if (productService == null) return true;

        // Compute delta = how much product inventory is being increased
        int delta;
        if (product.getId() != 0) {
            Product existing = productService.findById((int) product.getId());
            int oldInv = (existing != null ? existing.getInv() : 0);
            delta = product.getInv() - oldInv;
        } else {
            // new product; treat its inv as the delta
            delta = product.getInv();
        }

        // If not increasing inventory, nothing to consume => valid
        if (delta <= 0) return true;

        // Check each associated part will not drop below its Min after consumption
        for (Part p : product.getParts()) {
            if (p == null) continue;

            // If you track per-part quantity on the association, replace 'delta' with (delta * qty)
            int remaining = p.getInv() - delta;

            if (remaining < p.getMin()) {
            //if (remaining < (p.getMin() == null ? 0 : p.getMin())) {
                ctx.disableDefaultConstraintViolation();
                ctx.buildConstraintViolationWithTemplate(
                                String.format("Insufficient part inventory: \"%s\" would drop below Min (%d). " +
                                                "After increasing Product Inv by %d, remaining would be %d.",
                                        p.getName(), (p.getMin() == null ? 0 : p.getMin()), delta, remaining))
                        .addPropertyNode("inv")
                        .addConstraintViolation();
                return false;
            }

        }
        return true;
    }
}
