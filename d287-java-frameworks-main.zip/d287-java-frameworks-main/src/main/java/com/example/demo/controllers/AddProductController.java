package com.example.demo.controllers;

import com.example.demo.domain.Part;
import com.example.demo.domain.Product;
import com.example.demo.service.PartService;
import com.example.demo.service.ProductService;
import com.example.demo.service.ProductServiceImpl; // needed for context.getBean(...)
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;   // provides 'context' used in associatePart
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
@Controller
public class AddProductController {

    private final PartService partService;
    private final ProductService productService;

    @Autowired
    private ApplicationContext context; // so 'context' resolves in associatePart

    /** Keeps the in-progress product for associate/remove flows (matches your existing pattern). */
    private static Product product1 = new Product(); // ensure not null before getName()

    public AddProductController(PartService partService, ProductService productService) {
        this.partService = partService;
        this.productService = productService;
    }

    // ---------- helpers ----------

    private void populateListsForForm(Model model, Product p) {
        model.addAttribute("parts", partService.findAll());
        model.addAttribute("assparts", p.getParts());

        List<Part> availParts = new ArrayList<>();
        for (Part part : partService.findAll()) {
            if (!p.getParts().contains(part)) {
                availParts.add(part);
            }
        }
        model.addAttribute("availparts", availParts);
    }

    // ---------- create ----------

    @GetMapping("/showFormAddProduct")
    public String showFormAddProduct(Model model) {
        Product product = new Product();
        product1 = product;

        model.addAttribute("product", product);
        populateListsForForm(model, product);

        return "productForm";
    }

    @PostMapping("/showFormAddProduct")
    public String submitNewProduct(@Valid @ModelAttribute("product") Product product,
                                   BindingResult binding,
                                   Model model) {

        if (binding.hasErrors()) {
            // Keep the same @ModelAttribute('product') to preserve BindingResult attachment.
            // Just refresh the lists from current DB state (if editing) so side panels look right.
            Product basis = product.getId() > 0 ? productService.findById((int) product.getId()) : product;
            populateListsForForm(model, basis);
            return "productForm";
        }

        if (product.getId() != 0) {
            // ---- UPDATE FLOW ----
            Product existing = productService.findById((int) product.getId());
            int delta = product.getInv() - existing.getInv();

            if (delta > 0) {
                // Validate: consuming 'delta' of each associated part cannot go below min
                for (Part p : existing.getParts()) {
                    int resulting = p.getInv() - delta;
                    if (resulting < p.getMin()) {
                        // Attach field error to 'inv' and re-render without replacing 'product' in model
                        binding.rejectValue(
                                "inv",
                                "product.inv.parts.low",
                                "Increasing product inventory by " + delta +
                                        " would drop part '" + p.getName() + "' (id " + p.getId() +
                                        ") below its minimum (" + p.getMin() + ")."
                        );
                        // Rebuild side lists from current DB snapshot so the UI matches reality
                        populateListsForForm(model, existing);
                        return "productForm";
                    }
                }
                // Passed validation: apply consumption
                for (Part p : existing.getParts()) {
                    p.setInv(p.getInv() - delta);
                    partService.save(p);
                }
            }
            // Persist product core fields after validation
            existing.setName(product.getName());
            existing.setPrice(product.getPrice());
            existing.setInv(product.getInv());
            productService.save(existing);

        } else {
            // ---- CREATE FLOW ----
            // For a brand-new product you were forcing inv=0
            product.setInv(0);
            productService.save(product);
        }

        return "confirmationaddproduct";
    }

    // ---------- update (load form) ----------

    @GetMapping("/showProductFormForUpdate")
    public String showProductFormForUpdate(@RequestParam("productID") int id, Model model) {
        Product loaded = productService.findById(id);
        product1 = loaded;

        model.addAttribute("product", loaded);
        populateListsForForm(model, loaded);

        return "productForm";
    }

    // ---------- delete ----------

    @GetMapping("/deleteproduct")
    public String deleteProduct(@RequestParam("productID") int id) {
        Product toDelete = productService.findById(id);

        // Break both sides of the relation before deleting
        for (Part part : toDelete.getParts()) {
            part.getProducts().remove(toDelete);
            partService.save(part);
        }
        toDelete.getParts().clear();
        productService.save(toDelete);

        productService.deleteById(id);
        return "confirmationdeleteproduct";
    }

    // ---------- associate/remove parts (associatePart UNCHANGED) ----------

    @GetMapping("/associatepart")
    public String associatePart(@Valid @RequestParam("partID") int theID, Model theModel){
        if (product1.getName()==null) {
            return "saveproductscreen";
        } else {
            product1.getParts().add(partService.findById(theID));
            partService.findById(theID).getProducts().add(product1);
            ProductService productService = context.getBean(ProductServiceImpl.class);
            productService.save(product1);
            partService.save(partService.findById(theID));
            theModel.addAttribute("product", product1);
            theModel.addAttribute("assparts",product1.getParts());
            List<Part>availParts=new ArrayList<>();
            for(Part p: partService.findAll()){
                if(!product1.getParts().contains(p))availParts.add(p);
            }
            theModel.addAttribute("availparts",availParts);
            return "productForm";
        }
    }

    @GetMapping("/removepart")
    public String removePart(@RequestParam("partID") int partId, Model model) {
        if (product1 == null) {
            product1 = new Product();
        }

        Part part = partService.findById(partId);
        product1.getParts().remove(part);
        part.getProducts().remove(product1);

        productService.save(product1);
        partService.save(part);

        model.addAttribute("product", product1);
        populateListsForForm(model, product1);
        return "productForm";
    }
}

