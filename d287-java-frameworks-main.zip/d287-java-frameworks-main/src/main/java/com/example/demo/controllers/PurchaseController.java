package com.example.demo.controllers;

import com.example.demo.domain.Product;
import com.example.demo.repositories.ProductRepository;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@SuppressWarnings("unused") // Spring uses this controller via component scan
@Controller
public class PurchaseController {

    private final ProductRepository productRepository;

    public PurchaseController(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    /** Rubric F: decrement ONLY product inventory by 1 and show a message */
    @PostMapping("/products/{id}/buy")
    public String buyOne(@PathVariable Long id, RedirectAttributes ra) {
        Optional<Product> opt = productRepository.findById(id);
        if (opt.isEmpty()) {
            ra.addFlashAttribute("message", "Purchase failed: product not found.");
            return "redirect:/mainscreen";
        }
        Product p = opt.get();
        if (p.getInv() <= 0) {
            ra.addFlashAttribute("message", "Purchase failed: out of stock.");
            return "redirect:/mainscreen";
        }
        p.setInv(p.getInv() - 1); // do NOT touch parts inventory
        productRepository.save(p);
        ra.addFlashAttribute("message", "Purchase successful!");
        return "redirect:/mainscreen";
    }
}

