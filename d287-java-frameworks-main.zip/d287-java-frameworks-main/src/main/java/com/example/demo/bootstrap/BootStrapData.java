package com.example.demo.bootstrap;

import com.example.demo.domain.OutsourcedPart;
import com.example.demo.domain.Product;
import com.example.demo.repositories.OutsourcedPartRepository;
import com.example.demo.repositories.PartRepository;
import com.example.demo.repositories.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Profile("dev") // runs when spring.profiles.active=dev
public class BootStrapData implements CommandLineRunner {

    private final PartRepository partRepository;
    private final ProductRepository productRepository;
    private final OutsourcedPartRepository outsourcedPartRepository;

    public BootStrapData(PartRepository partRepository,
                         ProductRepository productRepository,
                         OutsourcedPartRepository outsourcedPartRepository) {
        this.partRepository = partRepository;
        this.productRepository = productRepository;
        this.outsourcedPartRepository = outsourcedPartRepository;
    }

    @Override
    public void run(String... args) {

        // reset for dev
        productRepository.deleteAll();
        partRepository.deleteAll();
        outsourcedPartRepository.deleteAll();

        // ---- Parts (ALL satisfy inv between min and max) ----
        OutsourcedPart p1 = new OutsourcedPart();
        p1.setName("Oak Table Leg");
        p1.setCompanyName("TopWorks Inc.");
        p1.setInv(60);   p1.setPrice(12.50);
        p1.setMin(10);   p1.setMax(100);   // 60 in [10,100]

        OutsourcedPart p2 = new OutsourcedPart();
        p2.setName("Oak Table Leg (2-pack)");
        p2.setCompanyName("TopWorks Inc.");
        p2.setInv(30);   p2.setPrice(24.00);
        p2.setMin(10);   p2.setMax(100);   // 30 in [10,100]

        OutsourcedPart p3 = new OutsourcedPart();
        p3.setName("Tabletop 60x36");
        p3.setCompanyName("TopWorks Inc.");
        p3.setInv(10);   p3.setPrice(85.00);
        p3.setMin(10);   p3.setMax(100);   // 10 in [10,100]

        OutsourcedPart p4 = new OutsourcedPart();
        p4.setName("Drawer Slide (pair)");
        p4.setCompanyName("SlideCo");
        p4.setInv(120);  p4.setPrice(9.50);
        p4.setMin(10);   p4.setMax(200);   // <-- raised max so 120 is valid

        OutsourcedPart p5 = new OutsourcedPart();
        p5.setName("Brushed Steel Knob");
        p5.setCompanyName("FastenMart");
        p5.setInv(200);  p5.setPrice(2.25);
        p5.setMin(10);   p5.setMax(250);   // <-- raised max so 200 is valid

        outsourcedPartRepository.saveAll(List.of(p1, p2, p3, p4, p5));

        // ---- Products ----
        Product prod1 = new Product("Modern Coffee Table", 199.99, 5);
        Product prod2 = new Product("Dining Chair", 129.99, 3);
        Product prod3 = new Product("Bookshelf 5-Tier", 179.99, 4);
        Product prod4 = new Product("TV Stand 60in", 279.99, 1);
        Product prod5 = new Product("Office Desk", 249.99, 2);

        productRepository.saveAll(List.of(prod1, prod2, prod3, prod4, prod5));

        System.out.println("✅ BootStrapData (dev) — database cleared and reseeded.");
        System.out.println("Parts count: " + partRepository.count());
        System.out.println("Products count: " + productRepository.count());
    }
}
