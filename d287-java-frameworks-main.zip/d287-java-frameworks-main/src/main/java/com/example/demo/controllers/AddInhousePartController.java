package com.example.demo.controllers;

import com.example.demo.domain.InhousePart;
import com.example.demo.service.InhousePartService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;

@SuppressWarnings("unused")
@Controller
public class AddInhousePartController {

    private final InhousePartService inhousePartService;

    public AddInhousePartController(InhousePartService inhousePartService) {
        this.inhousePartService = inhousePartService;
    }

    // ✅ Always ensure a model object exists (prevents Thymeleaf binding errors)
    @ModelAttribute("inhousepart")
    public InhousePart ensureInhousePart() {
        return new InhousePart();
    }

    // ✅ Add new part form
    @GetMapping("/showFormAddInPart")
    public String showFormAddInhousePart(Model model) {
        if (!model.containsAttribute("inhousepart")) {
            model.addAttribute("inhousepart", new InhousePart());
        }
        return "InhousePartForm";
    }

    // ✅ Edit (update) existing part form
    @GetMapping("/editInPart/{id}")
    public String editInhousePart(@PathVariable int id, Model model) {
        InhousePart existing = inhousePartService.findById(id);
        if (existing == null) {
            model.addAttribute("inhousepart", new InhousePart());
        } else {
            model.addAttribute("inhousepart", existing);
        }
        return "InhousePartForm";
    }

    // ✅ Save part (handles both add & update)
    @PostMapping("/showFormAddInPart")
    public String submitForm(
            @Valid @ModelAttribute("inhousepart") InhousePart part,
            BindingResult binding,
            Model model) {

        model.addAttribute("inhousepart", part);

        // If validation fails, stay on the same page
        if (binding.hasErrors()) {
            return "InhousePartForm";
        }

        // Preserve existing product links on edit
        if (part.getId() > 0) {
            InhousePart existing = inhousePartService.findById((int) part.getId());
            if (existing != null) {
                part.setProducts(existing.getProducts());
            }
        }

        // Save and show confirmation
        inhousePartService.save(part);
        return "confirmationaddpart";
    }
}
