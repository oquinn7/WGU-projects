package com.example.demo.domain;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class PartTest {

    // Validator for min/max tests
    private static Validator VALIDATOR;

    @BeforeAll
    static void initValidator() {
        // try-with-resources to avoid "not closed" inspection
        try (ValidatorFactory factory = Validation.buildDefaultValidatorFactory()) {
            VALIDATOR = factory.getValidator();
        }
    }

    Part partIn;
    Part partOut;

    @BeforeEach
    void setUp() {
        partIn = new InhousePart();
        partOut = new OutsourcedPart();
    }

    @Test
    void getId() {
        Long idValue = 4L;
        partIn.setId(idValue);
        assertEquals(idValue, partIn.getId());
        partOut.setId(idValue);
        assertEquals(idValue, partOut.getId());
    }

    @Test
    void setId() {
        Long idValue = 4L;
        partIn.setId(idValue);
        assertEquals(idValue, partIn.getId());
        partOut.setId(idValue);
        assertEquals(idValue, partOut.getId());
    }

    @Test
    void getName() {
        String name = "test inhouse part";
        partIn.setName(name);
        assertEquals(name, partIn.getName());
        name = "test outsourced part";
        partOut.setName(name);
        assertEquals(name, partOut.getName());
    }

    @Test
    void setName() {
        String name = "test inhouse part";
        partIn.setName(name);
        assertEquals(name, partIn.getName());
        name = "test outsourced part";
        partOut.setName(name);
        assertEquals(name, partOut.getName());
    }

    @Test
    void getPrice() {
        double price = 1.0;
        partIn.setPrice(price);
        assertEquals(price, partIn.getPrice());
        partOut.setPrice(price);
        assertEquals(price, partOut.getPrice());
    }

    @Test
    void setPrice() {
        double price = 1.0;
        partIn.setPrice(price);
        assertEquals(price, partIn.getPrice());
        partOut.setPrice(price);
        assertEquals(price, partOut.getPrice());
    }

    @Test
    void getInv() {
        int inv = 5;
        partIn.setInv(inv);
        assertEquals(inv, partIn.getInv());
        partOut.setInv(inv);
        assertEquals(inv, partOut.getInv());
    }

    @Test
    void setInv() {
        int inv = 5;
        partIn.setInv(inv);
        assertEquals(inv, partIn.getInv());
        partOut.setInv(inv);
        assertEquals(inv, partOut.getInv());
    }

    @Test
    void getProducts() {
        Product product1 = new Product();
        Product product2 = new Product();
        Set<Product> myProducts = new HashSet<>();
        myProducts.add(product1);
        myProducts.add(product2);
        partIn.setProducts(myProducts);
        assertEquals(myProducts, partIn.getProducts());
        partOut.setProducts(myProducts);
        assertEquals(myProducts, partOut.getProducts());
    }

    @Test
    void setProducts() {
        Product product1 = new Product();
        Product product2 = new Product();
        Set<Product> myProducts = new HashSet<>();
        myProducts.add(product1);
        myProducts.add(product2);
        partIn.setProducts(myProducts);
        assertEquals(myProducts, partIn.getProducts());
        partOut.setProducts(myProducts);
        assertEquals(myProducts, partOut.getProducts());
    }

    @Test
    void testToString() {
        String name = "test inhouse part";
        partIn.setName(name);
        assertEquals(name, partIn.toString());
        name = "test outsourced part";
        partOut.setName(name);
        assertEquals(name, partOut.toString());
    }

    @Test
    void testEquals() {
        partIn.setId(1L);
        Part newPartIn = new InhousePart();
        newPartIn.setId(1L);
        assertEquals(partIn, newPartIn);
        partOut.setId(1L);
        Part newPartOut = new OutsourcedPart();
        newPartOut.setId(1L);
        assertEquals(partOut, newPartOut);
    }

    @Test
    void testHashCode() {
        partIn.setId(1L);
        partOut.setId(1L);
        assertEquals(partIn.hashCode(), partOut.hashCode());
    }

    // -------- New rubric-required tests for min/max --------

    @Test
    void invBetweenMinMax_validWhenWithinBounds() {
        OutsourcedPart p = new OutsourcedPart();
        p.setName("Test Part");
        p.setPrice(1.0);
        p.setMin(2);
        p.setMax(10);
        p.setInv(5); // within bounds

        boolean hasBetweenMsg = VALIDATOR.validate(p).stream()
                .anyMatch(v -> "Inventory must be between Min and Max".equals(v.getMessage()));
        assertFalse(hasBetweenMsg);
    }

    @Test
    void invBetweenMinMax_violationWhenAboveMax() {
        OutsourcedPart p = new OutsourcedPart();
        p.setName("Test Part 2");
        p.setPrice(1.0);
        p.setMin(2);
        p.setMax(10);
        p.setInv(12); // above max

        boolean hasBetweenMsg = VALIDATOR.validate(p).stream()
                .anyMatch(v -> "Inventory must be between Min and Max".equals(v.getMessage()));
        assertTrue(hasBetweenMsg);
    }
}
